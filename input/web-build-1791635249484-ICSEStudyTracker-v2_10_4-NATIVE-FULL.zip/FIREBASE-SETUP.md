# Firebase push notifications (done)

Everything is already set up:
- `app/google-services.json` is included (Firebase project fir-app-786af, package `com.icse.class9studytracker`).
- The server side lives in the Floot project (secret FCM_SERVICE_ACCOUNT_JSON, action `push_register`, token table,
  push on every community post and DM).

Just build the APK. After you log in, the app sends its Firebase token to the server, shows one
"Notifications are on" test notification, and from then on new community posts and DMs arrive as
WhatsApp-style notifications, even when the app is closed.

Android 13+ asks for notification permission on first launch: tap Allow.

Never put the Firebase service-account private key (the other JSON file) inside this app.
