package com.icse.studytracker.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.icse.studytracker.data.AppState

/** Receives chat pushes from Firebase, even when the app is closed. */
class FcmService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        FcmRegister.send(applicationContext, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val d = message.data
        val state = AppState(applicationContext)
        if (d["type"] == "test") {
            if (state.cookie == null) return
            NotificationHelper.chat(applicationContext, 7001, d["title"].orEmpty().ifBlank { "Notifications are on" }, d["body"].orEmpty())
            return
        }
        if (d["type"] != "chat") return
        if (!state.notificationsEnabled || state.cookie == null) return
        if (LiveNotifyService.inForeground) return
        val kind = if (d["kind"] == "dm") "dm" else "community"
        val sender = d["sender"].orEmpty().ifBlank { "Student" }
        val body = d["body"].orEmpty()
        val at = d["at"]?.toLongOrNull() ?: System.currentTimeMillis()
        NotificationHelper.chatMessage(applicationContext, kind, sender, body, at)
    }
}
