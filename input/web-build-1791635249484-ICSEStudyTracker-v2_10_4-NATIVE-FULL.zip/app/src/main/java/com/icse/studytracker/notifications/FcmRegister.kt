package com.icse.studytracker.notifications

import android.content.Context
import com.google.firebase.messaging.FirebaseMessaging
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.AppState
import org.json.JSONObject
import kotlin.concurrent.thread

/** Gives this phone's Firebase token to the Floot server so it can push chat messages while the app is closed. */
object FcmRegister {
    /** Call after login and on every app start. Safe to call when Firebase is not set up: it just does nothing. */
    fun sync(context: Context) {
        val ctx = context.applicationContext
        val state = AppState(ctx)
        if (state.cookie == null || !state.notificationsEnabled) return
        try {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                if (!token.isNullOrBlank()) send(ctx, token)
            }
        } catch (e: Throwable) {
            // google-services.json missing or Google Play services unavailable: the built-in listener still works
        }
    }

    fun send(context: Context, token: String) {
        val ctx = context.applicationContext
        val state = AppState(ctx)
        state.put("fcmToken", token)
        if (state.cookie == null) return
        if (state.str("fcmSentToken") == token && state.str("fcmSentUser") == state.userId) return
        thread {
            try {
                Api.init(ctx)
                Api.tracker("push_register", JSONObject().put("token", token))
                state.put("fcmSentToken", token)
                state.put("fcmSentUser", state.userId)
                LiveNotifyService.stop(ctx)
            } catch (e: Exception) {
                // tried again on the next app start
            }
        }
    }
}
