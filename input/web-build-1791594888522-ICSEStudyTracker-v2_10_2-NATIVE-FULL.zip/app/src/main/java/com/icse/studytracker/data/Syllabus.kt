package com.icse.studytracker.data

import androidx.compose.ui.graphics.Color

/** Class IX 2026-27 annual-exam syllabus (same chapters as the web app). */
object Syllabus {
    val chapters: Map<String, List<String>> = linkedMapOf(
        "Physics" to listOf(
            "Laws of Motion",
            "Pressure in Fluids and Atmospheric Pressure",
            "Upthrust in Fluids, Archimedes' Principle and Floatation",
            "Reflection of Light",
            "Propagation of Sound Waves"
        ),
        "Chemistry" to listOf(
            "The Periodic Table",
            "Study of the First Element \u2014 Hydrogen",
            "Study of Gas Laws",
            "Periodic Table, Periodic Properties and Variation of Properties",
            "Chemical Bonding"
        ),
        "Biology" to listOf(
            "Economic Importance of Bacteria and Fungi",
            "Nutrition",
            "Skeleton: Movement and Locomotion",
            "Structure and Functions of Skin",
            "The Respiratory System",
            "Health and Hygiene",
            "Aids to Health",
            "Water Generation and Management"
        ),
        "Mathematics" to listOf(
            "Compound Interest",
            "Simultaneous Linear Equations",
            "Problems on Simultaneous Linear Equations",
            "Indices",
            "Midpoint Theorem",
            "Rectilinear Figures",
            "Theorems on Area",
            "Mensuration",
            "Co-ordinate Geometry",
            "Statistics"
        ),
        "History & Civics" to listOf(
            "History: South India and the Cholas",
            "History: The Delhi Sultanate",
            "History: The Mughal Empire",
            "History: The Composite Culture",
            "History: The Renaissance",
            "History: The Reformation",
            "History: Industrial Revolution, Capitalism and Socialism",
            "History Revision: Harappan Civilization",
            "History Revision: The Mauryan Empire",
            "History Revision: The Sangam Age",
            "History Revision: The Age of the Guptas",
            "Civics: Our Constitution and its Salient Features",
            "Civics: Elections and the Election Commission",
            "Civics: The State Legislatures"
        ),
        "Geography" to listOf(
            "Hydrosphere",
            "The Atmosphere",
            "Insolation",
            "Atmospheric Pressure and Winds",
            "Humidity",
            "Types of Pollution",
            "Sources of Pollution",
            "Effects and Preventive Measures of Pollution",
            "Major Natural Regions of the World",
            "Map Work"
        ),
        "Computer" to listOf(
            "Introduction to Object Oriented Programming Concepts",
            "Elementary Concept of Objects and Classes",
            "Values and Data Types",
            "Operators in Java",
            "Input in Java",
            "Mathematical Library Methods",
            "Conditional Statements in Java",
            "Iterative Constructs in Java",
            "Nested Loops"
        ),
        "English Literature" to listOf(
            "Julius Caesar: Act II, Scene I",
            "Julius Caesar: Act II, Scene II",
            "Julius Caesar: Act II, Scene III",
            "Julius Caesar: Act II, Scene IV",
            "Julius Caesar: Act I, Scene I (Revision)",
            "Julius Caesar: Act I, Scene II (Revision)",
            "Julius Caesar: Act I, Scene III (Revision)",
            "Poem: I Remember, I Remember",
            "Poem: Skimbleshanks: The Railway Cat",
            "Poem: A Work of Artifice",
            "Prose: The Home Coming",
            "Prose: The Boy Who Broke the Bank",
            "Prose: The Model Millionaire",
            "Prose: Oliver Asks for More"
        ),
        "English Grammar" to listOf(
            "Unseen Composition",
            "Letter Writing: Formal Letter",
            "Letter Writing: Informal Letter",
            "Notice Writing",
            "E-mail Writing",
            "Unseen Comprehension",
            "Grammar: Verbs",
            "Grammar: Prepositions",
            "Grammar: Join the Sentences",
            "Do as Directed: Transformation of Sentences",
            "Do as Directed: Voice Change",
            "Do as Directed: Narration Change"
        ),
        "Hindi" to listOf(
            "\u0917\u0926\u094D\u092F 1: \u092C\u093E\u0924 \u0905\u0920\u0928\u094D\u0928\u0940 \u0915\u0940",
            "\u0917\u0926\u094D\u092F 2: \u0915\u093E\u0915\u0940",
            "\u0917\u0926\u094D\u092F 3: \u092E\u0939\u093E\u092F\u091C\u094D\u091E \u0915\u093E \u092A\u0941\u0930\u0938\u094D\u0915\u093E\u0930",
            "\u0917\u0926\u094D\u092F 4: \u0928\u0947\u0924\u093E\u091C\u0940 \u0915\u093E \u091A\u0936\u094D\u092E\u093E",
            "\u0917\u0926\u094D\u092F 5: \u0905\u092A\u0928\u093E \u0905\u092A\u0928\u093E \u092D\u093E\u0917\u094D\u092F",
            "\u092A\u0926\u094D\u092F 1: \u0938\u093E\u0916\u0940",
            "\u092A\u0926\u094D\u092F 2: \u0917\u093F\u0930\u0927\u0930 \u0915\u0940 \u0915\u0941\u0902\u0921\u0932\u093F\u092F\u093E\u0901",
            "\u092A\u0926\u094D\u092F 3 (title unclear in the PDF)",
            "\u092A\u0926\u094D\u092F 4: \u0935\u0939 \u091C\u0928\u094D\u092E\u092D\u0942\u092E\u093F \u092E\u0947\u0930\u0940",
            "\u092A\u0926\u094D\u092F 5: \u092E\u0947\u0918 \u0906\u090F",
            "\u0935\u094D\u092F\u093E\u0915\u0930\u0923: \u0928\u093F\u092C\u0902\u0927 \u0914\u0930 \u091A\u093F\u0924\u094D\u0930 \u0932\u0947\u0916\u0928",
            "\u0935\u094D\u092F\u093E\u0915\u0930\u0923: \u0914\u092A\u091A\u093E\u0930\u093F\u0915 \u0914\u0930 \u0905\u0928\u094C\u092A\u091A\u093E\u0930\u093F\u0915 \u092A\u0924\u094D\u0930",
            "\u0935\u094D\u092F\u093E\u0915\u0930\u0923: \u0905\u092A\u0920\u093F\u0924 \u0917\u0926\u094D\u092F\u093E\u0902\u0936",
            "\u0935\u094D\u092F\u093E\u0915\u0930\u0923: \u0935\u093F\u0932\u094B\u092E \u0914\u0930 \u092A\u0930\u094D\u092F\u093E\u092F\u0935\u093E\u091A\u0940",
            "\u0935\u094D\u092F\u093E\u0915\u0930\u0923: \u092E\u0941\u0939\u093E\u0935\u0930\u0947",
            "\u0935\u094D\u092F\u093E\u0915\u0930\u0923: \u0915\u093E\u0932 \u0914\u0930 \u0935\u093E\u0915\u094D\u092F \u092A\u0930\u093F\u0935\u0930\u094D\u0924\u0928"
        ),
        "Commercial Studies" to listOf(
            "Finance and Accounts",
            "Human Resources",
            "Production",
            "Communication in Commercial Organisation",
            "Different Methods of Communication",
            "Meaning, Objectives and Terminology of Accounting",
            "Basic Accounting Principles and Concepts",
            "Banking",
            "Trade",
            "Social Responsibility towards the Environment",
            "Revision: Partnership",
            "Revision: Joint Stock Company",
            "Revision: Accounting Books and Statements"
        ),
        "Physical Education" to listOf(
            "Section A: Respiratory System",
            "Section A: Games and Sports",
            "Section A: Circulatory System",
            "Section B: Cricket",
            "Section B: Badminton"
        )
    )

    val allSubjects: List<String> = chapters.keys.toList()

    private val science = listOf(
        "Physics", "Chemistry", "Biology", "Mathematics", "History & Civics", "Geography", "Computer",
        "English Literature", "English Grammar", "Hindi"
    )
    private val commerce = listOf(
        "Commercial Studies", "Physical Education", "Mathematics", "History & Civics", "Geography", "Computer",
        "English Literature", "English Grammar", "Hindi"
    )

    fun subjectsFor(stream: String): List<String> =
        if (stream.contains("commerce", ignoreCase = true)) commerce else science

    fun chaptersOf(subject: String): List<String> = chapters[subject] ?: emptyList()

    fun key(subject: String, chapter: String): String = "$subject::$chapter"

    fun allKeys(stream: String): List<String> =
        subjectsFor(stream).flatMap { s -> chaptersOf(s).map { c -> key(s, c) } }

    fun colorOf(subject: String): Color = when (subject) {
        "Physics" -> Color(0xFFE8590C)
        "Chemistry" -> Color(0xFF7048E8)
        "Biology" -> Color(0xFF2F9E44)
        "Mathematics" -> Color(0xFF1C7ED6)
        "History & Civics" -> Color(0xFFC2255C)
        "Geography" -> Color(0xFF1098AD)
        "Computer" -> Color(0xFF8F8FFF)
        "English Literature" -> Color(0xFFD6336C)
        "English Grammar" -> Color(0xFFF783AC)
        "Hindi" -> Color(0xFFA9E34B)
        "Commercial Studies" -> Color(0xFF087F5B)
        "Physical Education" -> Color(0xFFF08C00)
        else -> Color(0xFF55E6EF)
    }
}
