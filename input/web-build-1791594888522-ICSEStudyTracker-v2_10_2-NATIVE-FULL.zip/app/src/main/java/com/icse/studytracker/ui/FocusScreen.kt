package com.icse.studytracker.ui

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.AppInfo
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.fmtClock
import com.icse.studytracker.data.Syllabus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

fun isAccessibilityOn(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return enabled.contains(ctx.packageName)
}

private fun launchableApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val fromLauncher = pm.queryIntentActivities(intent, 0)
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
    val fromInstalled = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        .map { AppInfo(pm.getApplicationLabel(it).toString(), it.packageName) }
    return (fromLauncher + fromInstalled)
        .filter { it.pkg != ctx.packageName && it.label.isNotBlank() }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun FocusScreen() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var accessOn by remember { mutableStateOf(isAccessibilityOn(ctx)) }
    var minutes by remember { mutableStateOf(25) }
    var custom by remember { mutableStateOf("") }
    var showChapters by remember { mutableStateOf(false) }
    var topicVersion by remember { mutableStateOf(0) }
    val focusManager = LocalFocusManager.current

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { launchableApps(ctx) }
        Repo.hydrateFocus(apps)
    }
    LaunchedEffect(Unit) {
        while (true) {
            accessOn = isAccessibilityOn(ctx)
            delay(1500)
        }
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (Repo.focusActive) {
            val left = (Repo.focusEnd - Repo.now) / 1000
            NeonCard {
                Kicker("FOCUS MODE IS ON")
                Text(
                    fmtClock(left), color = Txt, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                MutedText("${Repo.focusPackages.size} app${if (Repo.focusPackages.size == 1) " is" else "s are"} blocked until the timer ends. This time is added to your study time when the session ends.", Modifier.fillMaxWidth())
                NeonButton("End focus session", { Repo.endFocus() }, Modifier.fillMaxWidth(), secondary = true)
            }
        } else {
            NeonCard {
                Kicker("FOCUS MODE")
                H1("Block distractions while you study")
                MutedText("Pick the apps that distract you. While a session runs, opening one of them sends you straight back to the home screen.")
            }

            NeonCard {
                Kicker("STEP 1 \u00B7 ALLOW BLOCKING")
                if (accessOn) {
                    Body("\u2705 Blocking permission is on.", color = Good, size = 14)
                } else {
                    MutedText("Android needs the accessibility permission so the app can notice when a blocked app opens. Open the settings, choose \"ICSE Study Tracker Focus Mode\" and switch it on.")
                    NeonButton("Open accessibility settings", {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }, Modifier.fillMaxWidth())
                    MutedText("If the switch is greyed out (Android blocks it for apps installed from outside the Play Store): open App info, tap the \u22EE menu at the top right, choose \"Allow restricted settings\", then switch it on. After updating the app you may need to switch it on again.")
                    NeonButton("Open App info", {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }, Modifier.fillMaxWidth(), secondary = true)
                }
            }

            NeonCard {
                Kicker("STEP 2 \u00B7 CHOOSE APPS TO BLOCK (${Repo.focusPackages.size})")
                Field(query, { query = it }, "Search your apps", Modifier.fillMaxWidth())
                val q = query.trim().lowercase()
                val selected = apps.filter { Repo.focusPackages.contains(it.pkg) }
                val others = apps.filter { !Repo.focusPackages.contains(it.pkg) && (q.isEmpty() || it.label.lowercase().contains(q)) }
                val shown = (if (q.isEmpty()) selected else selected.filter { it.label.lowercase().contains(q) }) +
                    (if (q.isEmpty()) others.take(40) else others)
                if (apps.isEmpty()) MutedText("Loading your apps\u2026")
                for (a in shown) {
                    val on = Repo.focusPackages.contains(a.pkg)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { Repo.toggleFocusApp(a) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TickBox(on, { Repo.toggleFocusApp(a) })
                        Avatar(a.label, 30)
                        Text(a.label, color = Txt, fontSize = 15.sp, modifier = Modifier.weight(1f), maxLines = 1)
                    }
                }
                if (q.isEmpty() && others.size > 40) MutedText("Type in the search box to find more apps.")
            }

            NeonCard {
                Kicker("STEP 3 \u00B7 WHAT WILL YOU STUDY?")
                MutedText("Focus time is added to your study time, with this subject and topic.")
                val subjects = Syllabus.subjectsFor(Repo.stream)
                val chosen = if (subjects.contains(Repo.focusSubject)) Repo.focusSubject else subjects.first()
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (sub in subjects) Chip(sub, sub == chosen, { Repo.chooseFocusSubject(sub) }, Syllabus.colorOf(sub))
                }
                key(topicVersion) {
                    Field(Repo.focusTopic, { Repo.chooseFocusTopic(it) }, "Topic / chapter (optional)", Modifier.fillMaxWidth())
                }
                if (Repo.focusTopic.isNotBlank()) Body("Selected topic: ${Repo.focusTopic}", color = Cyan, size = 13)
                Chip(if (showChapters) "Hide chapters" else "Choose from $chosen chapters", false, { showChapters = !showChapters })
                if (showChapters) {
                    for (c in Syllabus.chaptersOf(chosen)) {
                        Text(
                            c,
                            color = if (Repo.focusTopic == c) Cyan else Txt,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { focusManager.clearFocus(); Repo.chooseFocusTopic(c); topicVersion++; showChapters = false }
                                .padding(vertical = 7.dp)
                        )
                    }
                }
            }

            NeonCard {
                Kicker("STEP 4 \u00B7 START A SESSION")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (m in listOf(15, 25, 45, 60, 90)) Chip("${m}m", custom.isBlank() && minutes == m, { minutes = m; custom = "" })
                }
                Field(custom, { custom = it.filter { c -> c.isDigit() }.take(3) }, "Or type minutes", Modifier.fillMaxWidth(), keyboard = KeyboardType.Number)
                NeonButton("Start focus session", {
                    val m = custom.toIntOrNull() ?: minutes
                    when {
                        !accessOn -> Repo.toast("Turn on the blocking permission first (step 1)")
                        Repo.focusPackages.isEmpty() -> Repo.toast("Choose at least one app to block (step 2)")
                        m < 1 -> Repo.toast("Enter the number of minutes")
                        else -> Repo.startFocus(m)
                    }
                }, Modifier.fillMaxWidth())
            }
        }
    }
}
