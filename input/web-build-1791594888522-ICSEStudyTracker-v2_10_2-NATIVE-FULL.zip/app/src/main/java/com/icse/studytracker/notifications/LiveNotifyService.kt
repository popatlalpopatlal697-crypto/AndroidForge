package com.icse.studytracker.notifications

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.AppState
import com.icse.studytracker.data.objects
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Checks the server every ~20 seconds for new community / DM messages and for classmates who just studied,
 * and shows a notification for each. It keeps a tiny silent notification so Android does not stop it.
 */
class LiveNotifyService : Service() {
    companion object {
        private const val NOTIFICATION_ID = 8

        @Volatile
        var inForeground = false

        fun start(context: Context) {
            try {
                val i = Intent(context, LiveNotifyService::class.java)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
            } catch (e: Exception) {
                // not allowed right now (for example the app is in the background); it starts next time the app opens
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, LiveNotifyService::class.java))
            } catch (e: Exception) {
                // ignore
            }
        }

        private fun isoNow(): String {
            val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            f.timeZone = TimeZone.getTimeZone("UTC")
            return f.format(java.util.Date())
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val pollLock = Mutex()
    private var socket: WebSocket? = null
    private var retry = 0
    private var stopped = false
    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.channels(this)
        val notification = NotificationCompat.Builder(this, NotificationHelper.LIVE_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("ICSE Study Tracker")
            .setContentText("Listening for new messages and classmates studying")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        if (job == null) {
            job = scope.launch { loop() }
            scope.launch { heartbeatLoop() }
            connectRealtime()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // the app was swiped away: make sure the listener keeps running
        start(applicationContext)
        super.onTaskRemoved(rootIntent)
    }

    // ---- Supabase Realtime (instant pings) ----
    private fun connectRealtime() {
        if (stopped) return
        try {
            val req = Request.Builder()
                .url(Supabase.WS + "?apikey=" + Supabase.ANON + "&vsn=1.0.0")
                .build()
            socket = http.newWebSocket(req, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    retry = 0
                    val config = JSONObject()
                        .put("broadcast", JSONObject().put("self", false).put("ack", false))
                        .put("presence", JSONObject().put("key", ""))
                        .put("postgres_changes", org.json.JSONArray())
                        .put("private", false)
                    val join = JSONObject()
                        .put("topic", "realtime:" + Supabase.TOPIC)
                        .put("event", "phx_join")
                        .put("payload", JSONObject().put("config", config).put("access_token", Supabase.ANON))
                        .put("ref", "1")
                        .put("join_ref", "1")
                    webSocket.send(join.toString())
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    handleSocketMessage(text)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    scheduleReconnect()
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    scheduleReconnect()
                }
            })
        } catch (e: Exception) {
            scheduleReconnect()
        }
    }

    private fun scheduleReconnect() {
        if (stopped) return
        retry++
        val wait = Math.min(30_000L, 2_000L * retry)
        scope.launch {
            delay(wait)
            connectRealtime()
        }
    }

    private suspend fun heartbeatLoop() {
        var n = 100
        while (!stopped) {
            delay(25_000L)
            try {
                n++
                socket?.send(JSONObject().put("topic", "phoenix").put("event", "heartbeat").put("payload", JSONObject()).put("ref", n.toString()).toString())
            } catch (e: Exception) {
                // reconnect handles failures
            }
        }
    }

    private fun handleSocketMessage(text: String) {
        try {
            val root = JSONObject(text)
            if (root.optString("event") != "broadcast") return
            val outer = root.optJSONObject("payload") ?: return
            val ping = outer.optJSONObject("payload") ?: return
            onPing(ping)
        } catch (e: Exception) {
            // ignore malformed frames
        }
    }

    private fun onPing(p: JSONObject) {
        val ctx = applicationContext
        val state = AppState(ctx)
        if (!state.notificationsEnabled || state.cookie == null) return
        val me = state.userId
        if (p.optString("fromId") == me) return
        when (p.optString("t")) {
            "msg" -> {
                val to = p.optString("to")
                if (to == "all" || to == me) {
                    scope.launch {
                        pollLock.withLock {
                            try {
                                pollMessages(ctx, state)
                            } catch (e: Exception) {
                                // the regular check will retry
                            }
                        }
                    }
                }
            }
            "study" -> {
                if (!inForeground) {
                    val name = p.optString("from", "A classmate")
                    val subject = p.optString("subject")
                    NotificationHelper.friendStudy(
                        ctx, 3000 + Math.abs(name.hashCode() % 1000),
                        "\uD83D\uDCDA $name is studying",
                        if (subject.isBlank()) "$name just started studying. Join in!" else "$name just started studying $subject. Join in!"
                    )
                }
            }
        }
    }

    private suspend fun loop() {
        val ctx = applicationContext
        val state = AppState(ctx)
        Api.init(ctx)
        var tick = 0
        while (true) {
            if (!state.notificationsEnabled || state.cookie == null) {
                stopSelf()
                return
            }
            try {
                pollLock.withLock { pollMessages(ctx, state) }
            } catch (e: Exception) {
                // try again next round
            }
            if (tick % 3 == 0) {
                try {
                    pollStudy(ctx, state)
                } catch (e: Exception) {
                    // try again next round
                }
            }
            tick++
            delay(20_000L)
        }
    }

    private fun pollMessages(ctx: Context, state: AppState) {
        if (state.lastNotificationAt.isBlank()) {
            // first run: start from now so old messages do not pop up
            state.lastNotificationAt = isoNow()
            return
        }
        val data = Api.trackerObj("notifications", JSONObject().put("since", state.lastNotificationAt))
        val items = data.optJSONArray("items")?.objects() ?: emptyList()
        var newest = state.lastNotificationAt
        for (item in items) {
            val created = item.optString("createdAt")
            if (created > newest) newest = created
            if (inForeground) continue
            val who = item.optString("displayName", "Student")
            val kind = if (item.optString("type") == "dm") "dm" else "community"
            val at = com.icse.studytracker.data.parseIso(created).let { if (it > 0L) it else System.currentTimeMillis() }
            NotificationHelper.chatMessage(ctx, kind, who, item.optString("body"), at)
        }
        if (newest.isNotBlank()) state.lastNotificationAt = newest
    }

    private fun pollStudy(ctx: Context, state: AppState) {
        val tz = TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000
        val arr = Api.trackerArr("leaderboard", JSONObject().put("period", "day").put("tzOffsetMinutes", tz))
        val prevRaw = state.str("study_snapshot")
        val prev = try { JSONObject(if (prevRaw.isBlank()) "{}" else prevRaw) } catch (e: Exception) { JSONObject() }
        val next = JSONObject()
        val me = state.userName
        for (row in arr.objects()) {
            val name = row.optString("displayName", "Student")
            val minutes = row.optDouble("totalMinutes", 0.0)
            next.put(name, minutes)
            if (name != me && prev.has(name) && !inForeground) {
                val gained = minutes - prev.optDouble(name, 0.0)
                if (gained >= 0.5) {
                    val mins = Math.max(1, Math.round(gained).toInt())
                    NotificationHelper.friendStudy(
                        ctx, 3000 + Math.abs(name.hashCode() % 1000),
                        "\uD83D\uDCDA $name is studying",
                        "$name just studied $mins more minute${if (mins == 1) "" else "s"}. Keep up!"
                    )
                }
            }
        }
        state.put("study_snapshot", next.toString())
    }

    override fun onDestroy() {
        stopped = true
        try {
            socket?.close(1000, "bye")
        } catch (e: Exception) {
            // ignore
        }
        job?.cancel()
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }
}
