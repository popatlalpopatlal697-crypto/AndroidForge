package com.icse.studytracker.data

import java.util.Calendar
import java.util.Random

/**
 * Builds the three Sunday tests.
 *
 * Each test covers ONE random chapter of ONE random subject (three different subjects per week) and has 35-40
 * questions: mostly multiple-choice (auto-marked, from the question bank, same chapter first) plus 8-10 written
 * high-thinking questions that the student answers on paper, photographs and marks honestly. The seed changes every week, so the
 * tests are fresh each Sunday but identical for every student.
 */
object TestBuilder {
    fun weekSeed(): Long {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 100L + c.get(Calendar.WEEK_OF_YEAR)
    }

    /** This week's three (slot, subject, chapter) picks. Same for every student of a stream, new every Sunday. */
    fun pickTargets(stream: String): List<Triple<Int, String, String>> {
        val seed = weekSeed()
        val subjects = ArrayList(Syllabus.subjectsFor(stream))
        subjects.shuffle(Random(seed * 7919L))
        val out = ArrayList<Triple<Int, String, String>>()
        for (slot in 0 until 3) {
            val rnd = Random(seed * 1000L + slot * 37L)
            val subject = subjects[slot % subjects.size]
            val chapters = Syllabus.chaptersOf(subject).ifEmpty { listOf(subject) }
            out.add(Triple(slot, subject, chapters[rnd.nextInt(chapters.size)]))
        }
        return out
    }

    private fun subjectMatches(subject: String, poolSubject: String): Boolean {
        val ss = subject.lowercase()
        val ps = poolSubject.lowercase()
        return when {
            ss.startsWith("english") -> ps.contains("english")
            ss.startsWith("history") -> ps.contains("histor") || ps.contains("civic")
            ss == "mathematics" -> ps.contains("math")
            ss == "commercial studies" -> ps.contains("commerc")
            ss == "physical education" -> ps.contains("physical")
            else -> ps.contains(ss) || ss.contains(ps)
        }
    }

    private fun words(text: String): Set<String> =
        text.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 4 }.toSet()

    fun buildChapterTests(stream: String, pool: List<Question>): List<TestDef> {
        val seed = weekSeed()
        val bank = pool.filter { !it.written && it.options.size >= 2 && it.answer in it.options.indices }
        val subjects = ArrayList(Syllabus.subjectsFor(stream))
        subjects.shuffle(Random(seed * 7919L))
        // subjects with a decent question bank come first, so the tests can be mostly multiple-choice
        val rich = subjects.filter { s -> bank.count { subjectMatches(s, it.subject) } >= 8 }
        val ordered = rich + subjects.filter { !rich.contains(it) }
        val out = ArrayList<TestDef>()
        for (slot in 0 until 3) {
            val rnd = Random(seed * 1000L + slot * 37L)
            val subject = ordered[slot % ordered.size]
            val chapters = Syllabus.chaptersOf(subject)
            val chapter = chapters[rnd.nextInt(chapters.size)]
            val total = 30 + rnd.nextInt(6)
            val writtenMin = 6 + rnd.nextInt(3)
            val mcqs = chapterMcqs(subject, chapter, bank, total - writtenMin, rnd)
            val stems = ArrayList(generic + specific(subject))
            stems.shuffle(rnd)
            val photo = photoSubject(subject)
            val writtenCount = Math.min(total - mcqs.size, stems.size)
            val questions = ArrayList<Question>(mcqs)
            for (i in 0 until writtenCount) {
                val text = stems[i].replace("{c}", chapter).replace("{s}", subject)
                questions.add(
                    Question(
                        q = text, options = emptyList(), answer = -1, explanation = "", marks = 2,
                        difficulty = "high-thinking", subject = subject, chapter = chapter,
                        written = true, photoRequired = photo
                    )
                )
            }
            out.add(TestDef(slot, questions, subject, chapter))
        }
        return out
    }

    /** Multiple-choice questions for the test: same-chapter questions first, then the rest of the subject. */
    private fun chapterMcqs(subject: String, chapter: String, bank: List<Question>, target: Int, rnd: Random): List<Question> {
        val mine = bank.filter { subjectMatches(subject, it.subject) }
        if (mine.isEmpty() || target <= 0) return emptyList()
        val cw = words(chapter)
        val ranked = mine.shuffled(rnd).sortedByDescending { q -> words(q.chapter).count { cw.contains(it) } }
        val out = ArrayList<Question>()
        // pass 1: the questions themselves
        for (q in ranked) {
            if (out.size >= target) break
            out.add(q.copy(difficulty = if (q.difficulty.isBlank()) "high-thinking" else q.difficulty))
        }
        // pass 2: "which explanation justifies the answer?" (needs 3 other explanations as distractors)
        val expl = mine.filter { it.explanation.isNotBlank() }
        if (out.size < target && expl.size >= 4) {
            for (q in ranked) {
                if (out.size >= target) break
                if (q.explanation.isBlank()) continue
                val others = expl.filter { it.explanation != q.explanation }.shuffled(rnd).take(3).map { it.explanation }
                if (others.size < 3) continue
                val options = ArrayList(others)
                val at = rnd.nextInt(4)
                options.add(at, q.explanation)
                out.add(
                    Question(
                        q = "Which explanation best justifies the correct answer to this question?\n\n\"" + q.q + "\"",
                        options = options, answer = at, explanation = "Correct answer: " + q.options[q.answer],
                        marks = q.marks, difficulty = "hard", subject = q.subject, chapter = q.chapter
                    )
                )
            }
        }
        // pass 3: true / false checks on the stated answer
        if (out.size < target) {
            for (q in ranked) {
                if (out.size >= target) break
                val wrongs = q.options.indices.filter { it != q.answer }
                val useTrue = rnd.nextBoolean()
                val shown = if (useTrue || wrongs.isEmpty()) q.answer else wrongs[rnd.nextInt(wrongs.size)]
                out.add(
                    Question(
                        q = "True or False? For the question \"" + q.q + "\" the correct answer is \"" + q.options[shown] + "\".",
                        options = listOf("True", "False"), answer = if (shown == q.answer) 0 else 1,
                        explanation = "Correct answer: " + q.options[q.answer],
                        marks = 1, difficulty = "medium", subject = q.subject, chapter = q.chapter
                    )
                )
            }
        }
        out.shuffle(rnd)
        return out
    }

    fun photoSubject(subject: String): Boolean = when (subject) {
        "Mathematics", "Physics", "Chemistry", "Biology", "Computer", "Geography", "Commercial Studies", "Physical Education" -> true
        else -> false
    }

    private val generic = listOf(
        "Explain the central idea of \"{c}\" in your own words, as if teaching a classmate who missed the lesson.",
        "List the 5 most important terms or definitions in \"{c}\" and explain how they connect to each other.",
        "Which part of \"{c}\" is the hardest to understand? Explain it clearly and correct one common misconception.",
        "Create a challenging question on \"{c}\" that needs more than one step, then answer it fully.",
        "Explain why \"{c}\" matters in {s}, linking it with at least one other chapter you have studied.",
        "Compare two key ideas from \"{c}\": what is the same, what is different, and when would you use each?",
        "Give a real-life situation that illustrates \"{c}\" and explain it using the ideas of the chapter.",
        "Summarise \"{c}\" as a labelled mind-map or flow chart and explain every branch.",
        "Write a \"what if?\" question about \"{c}\" (change one condition) and explain what would happen and why.",
        "Identify 3 mistakes students often make in \"{c}\" and show the correct method for each.",
        "Explain the order of ideas in \"{c}\": what must you understand first, second and third, and why?",
        "Write a mini-quiz of 3 hard questions on \"{c}\" with complete model answers.",
        "Choose the single most important idea in \"{c}\" and defend your choice with evidence from the chapter.",
        "Explain \"{c}\" to a younger student using an analogy, then explain where the analogy breaks down.",
        "Pick one important fact or result from \"{c}\" and explain how we know it is true.",
        "Describe how you would revise \"{c}\" in 20 minutes and write the 5 points you must never forget.",
        "Link two different parts of \"{c}\" to explain something that neither part explains alone.",
        "Write an exam-style long answer on \"{c}\", then mark your own answer against the textbook.",
        "What question about \"{c}\" would a very strict examiner ask to test deep understanding? Ask it and answer it.",
        "Identify the cause-and-effect chains in \"{c}\" and explain each link.",
        "Explain how \"{c}\" would change if one key condition or assumption were different.",
        "Evaluate the strengths and limits of the main method or idea in \"{c}\".",
        "Write a 5-step lesson plan that teaches \"{c}\" with an example for each step.",
        "Connect \"{c}\" to something from daily life, the news or another subject and explain the link in detail."
    )

    private fun specific(subject: String): List<String> = when (subject) {
        "Mathematics" -> math
        "Physics" -> physics
        "Chemistry" -> chemistry
        "Biology" -> biology
        "Computer" -> computer
        "History & Civics" -> history
        "Geography" -> geography
        "English Literature" -> literature
        "English Grammar" -> grammar
        "Hindi" -> hindi
        "Commercial Studies" -> commerce
        else -> pe
    }

    private val math = listOf(
        "Prove or derive the main result or formula of \"{c}\" step by step.",
        "Create a 4-step numerical problem from \"{c}\", solve it with full working, and check the answer a second way.",
        "Write a worked solution on \"{c}\" with one deliberate mistake, then find and fix the mistake.",
        "Solve one problem from \"{c}\" in two different ways and say which method is better and why.",
        "State when the formula or theorem in \"{c}\" does not apply and give an example.",
        "Make up a real-life word problem on \"{c}\" and solve it completely.",
        "Prove a converse or special case related to \"{c}\" and explain why it works.",
        "Show how \"{c}\" connects to another chapter of Mathematics with a worked example.",
        "Solve a hard exam-level problem from \"{c}\" and justify every step.",
        "Draw a neat, accurate diagram or graph for \"{c}\" and use it to solve a problem.",
        "Write the key formulas or theorems of \"{c}\" with a one-line proof idea for each.",
        "Design a problem where a common shortcut in \"{c}\" gives the wrong answer and show why."
    )

    private val physics = listOf(
        "Derive the key relation(s) of \"{c}\" from first principles.",
        "Solve a 3-part numerical on \"{c}\" with units and explain the physics behind each step.",
        "Draw a neat labelled diagram for \"{c}\" and explain what each part shows.",
        "Design a simple experiment to show \"{c}\": aim, apparatus, procedure, observation and conclusion.",
        "Explain an everyday phenomenon using \"{c}\" with proper physical reasoning.",
        "Predict what happens if one quantity in \"{c}\" is doubled or halved and justify it with equations.",
        "Explain why a common wrong idea about \"{c}\" is wrong, using an example.",
        "Compare two situations from \"{c}\" quantitatively.",
        "State the laws or principles in \"{c}\" and give one application and one limitation of each.",
        "Check the units or dimensions of the main formula of \"{c}\".",
        "Sketch the graph that best represents \"{c}\" and interpret its slope or area.",
        "Explain how \"{c}\" is used in technology or transport, with reasoning."
    )

    private val chemistry = listOf(
        "Write and balance 4 equations related to \"{c}\" and explain what each shows.",
        "Explain the trend or rule in \"{c}\" across a group or period, with reasons.",
        "Draw a neat diagram (apparatus, structure or bonding) for \"{c}\" and explain it.",
        "Explain the preparation, properties and uses in \"{c}\" step by step with reasons.",
        "Solve a numerical based on \"{c}\" (moles, volume, mass or a gas law) with full working.",
        "Explain the experiment, observations and inferences connected with \"{c}\".",
        "Predict the product or behaviour in a new example from \"{c}\" and justify it.",
        "Explain why exceptions exist to the main rule of \"{c}\".",
        "Compare two substances, elements or processes from \"{c}\" in a table with reasoning.",
        "Explain a daily-life or industrial application of \"{c}\" and the chemistry behind it.",
        "Write the key definitions of \"{c}\" with one example each.",
        "What happens if one condition (temperature, pressure or reactant) changes in \"{c}\"? Explain."
    )

    private val biology = listOf(
        "Draw a neat, fully labelled diagram for \"{c}\" and explain each part's function.",
        "Explain the process in \"{c}\" step by step and predict what happens if one step fails.",
        "Compare two structures, processes or diseases from \"{c}\" in a table with reasons.",
        "Explain how \"{c}\" keeps the human body healthy or in balance.",
        "Write a case study: a student faces a problem related to \"{c}\"; diagnose it and advise.",
        "Explain the cause, symptoms, prevention and control logic in \"{c}\" where applicable.",
        "Design a simple experiment or observation that shows a concept from \"{c}\".",
        "Explain how \"{c}\" is connected to another system of the body.",
        "Explain why the structure of one organ or part in \"{c}\" suits its function.",
        "Make a flow chart for \"{c}\" and explain each arrow.",
        "Write 5 hard why/how questions from \"{c}\" and answer them.",
        "Explain the importance of \"{c}\" for the environment or society, with examples."
    )

    private val computer = listOf(
        "Write a complete Java program that uses the key concept of \"{c}\" and explain it line by line.",
        "Dry run a program from \"{c}\" with a trace table and show the output.",
        "Find and fix the errors in a buggy program on \"{c}\".",
        "Solve one task in two different ways using \"{c}\" and compare the two programs.",
        "Write the output of 3 tricky code snippets from \"{c}\" with reasoning.",
        "Explain the syntax rules of \"{c}\" with correct and incorrect examples.",
        "Turn a real-life problem into an algorithm or flowchart using \"{c}\".",
        "Write a program using \"{c}\" that takes input from the user and show 2 sample runs.",
        "List common compile-time and run-time errors in \"{c}\" and how to avoid them.",
        "Explain the difference between two similar concepts in \"{c}\" with code.",
        "Design a mini-program (calculator, menu or pattern) using \"{c}\".",
        "Simplify a program on \"{c}\" and explain why the new version is better."
    )

    private val history = listOf(
        "Analyse the causes, events and consequences of \"{c}\" in a structured answer.",
        "Explain the significance of \"{c}\" in the larger story of history or civics.",
        "Compare \"{c}\" with a related chapter or period: similarities, differences and links.",
        "Evaluate who benefited and who suffered because of \"{c}\", and justify your view.",
        "Explain 5 key terms, personalities or dates of \"{c}\" and why each matters.",
        "Write 5 likely short-answer questions on \"{c}\" with answers.",
        "Explain how things might have been different if one key event of \"{c}\" had not happened.",
        "Write a letter or diary entry by a person of that time describing \"{c}\" with accurate facts.",
        "Draw a timeline or flow chart of \"{c}\" and explain the links between events.",
        "How is \"{c}\" still relevant to India or the world today? Explain with examples.",
        "Explain the sources of evidence we use to know about \"{c}\" and how reliable they are.",
        "Critically discuss one popular belief about \"{c}\"."
    )

    private val geography = listOf(
        "Draw a neat labelled diagram or map for \"{c}\" and explain each part.",
        "Explain the causes and effects of the main process in \"{c}\" step by step.",
        "Compare two regions, layers or processes from \"{c}\" in a table with reasons.",
        "Explain how \"{c}\" affects human life, climate or the environment, with examples.",
        "Write 5 hard why/how questions on \"{c}\" and answer them.",
        "Explain how to read a diagram, graph or data table for \"{c}\" step by step.",
        "Explain the link between \"{c}\" and another geography chapter.",
        "Suggest measures to deal with a problem from \"{c}\" and justify each.",
        "Explain a real place or example for \"{c}\" in detail.",
        "Draw a flow chart showing how one thing in \"{c}\" leads to another.",
        "What would happen if one factor in \"{c}\" changed (temperature, pressure or location)? Explain.",
        "Write the important definitions of \"{c}\" with one example each."
    )

    private val literature = listOf(
        "Analyse the main theme(s) of \"{c}\" with evidence from the text.",
        "Describe the main character(s) in \"{c}\" and how they change, using evidence from the text.",
        "Explain the literary or poetic devices in \"{c}\" and their effect on the reader.",
        "State the central message of \"{c}\" and say whether you agree with it, and why.",
        "Rewrite an important moment of \"{c}\" from another character's point of view.",
        "Explain the setting and mood in \"{c}\" and how the writer builds them.",
        "Compare \"{c}\" with another text you have read: ideas, style and message.",
        "Explain the meaning of five important lines or phrases from \"{c}\" in your own words and why they matter.",
        "Choose an important passage from \"{c}\" and explain its context, meaning and significance.",
        "Predict how the story or play might continue and justify it with clues from the text.",
        "Discuss the title of \"{c}\": is it suitable, and why?",
        "Write a character sketch or theme essay of about 200 words on \"{c}\"."
    )

    private val grammar = listOf(
        "Write 8 original sentences that follow the rules of \"{c}\" correctly.",
        "Write 6 incorrect sentences on \"{c}\" and correct each one, naming the rule.",
        "Explain the rules of \"{c}\" with one example for each.",
        "Create an exercise of 6 questions on \"{c}\" with an answer key.",
        "Rewrite a 5-sentence paragraph applying \"{c}\" correctly.",
        "Explain 3 tricky exceptions or confusing cases in \"{c}\".",
        "Write a short passage (60\u201380 words) that uses \"{c}\" at least 5 times and underline each use.",
        "Compare two similar rules or forms in \"{c}\" and show when each is used.",
        "Write a model answer for an exam question on \"{c}\" (format, tone and language).",
        "Convert 5 sentences using the pattern in \"{c}\" and explain each change.",
        "Explain how \"{c}\" makes writing and speaking clearer, with examples.",
        "Find and fix 5 errors in a paragraph related to \"{c}\"."
    )

    private val hindi = listOf(
        "\"{c}\" \u0915\u093E \u0938\u093E\u0930 \u0905\u092A\u0928\u0947 \u0936\u092C\u094D\u0926\u094B\u0902 \u092E\u0947\u0902 \u0932\u093F\u0916\u093F\u090F\u0964",
        "\"{c}\" \u0938\u0947 \u091C\u0941\u0921\u093C\u0947 \u092A\u093E\u0901\u091A \u092E\u0939\u0924\u094D\u0935\u092A\u0942\u0930\u094D\u0923 \u0936\u092C\u094D\u0926 \u092F\u093E \u0905\u0935\u0927\u093E\u0930\u0923\u093E\u090F\u0901 \u0938\u092E\u091D\u093E\u0907\u090F\u0964",
        "\"{c}\" \u0915\u093E \u092E\u0941\u0916\u094D\u092F \u0938\u0902\u0926\u0947\u0936 \u092F\u093E \u092D\u093E\u0935 \u0938\u094D\u092A\u0937\u094D\u091F \u0915\u0940\u091C\u093F\u090F \u0914\u0930 \u0905\u092A\u0928\u0947 \u0935\u093F\u091A\u093E\u0930 \u0932\u093F\u0916\u093F\u090F\u0964",
        "\"{c}\" \u092A\u0930 \u0906\u0927\u093E\u0930\u093F\u0924 \u092A\u093E\u0901\u091A \u092A\u0930\u0940\u0915\u094D\u0937\u093E-\u0936\u0948\u0932\u0940 \u092A\u094D\u0930\u0936\u094D\u0928 \u092C\u0928\u093E\u0915\u0930 \u0909\u0928\u0915\u0947 \u0909\u0924\u094D\u0924\u0930 \u0932\u093F\u0916\u093F\u090F\u0964",
        "\"{c}\" \u092E\u0947\u0902 \u092A\u094D\u0930\u092F\u0941\u0915\u094D\u0924 \u092D\u093E\u0937\u093E \u092F\u093E \u0936\u0948\u0932\u0940 \u0915\u0940 \u0935\u093F\u0936\u0947\u0937\u0924\u093E\u090F\u0901 \u092C\u0924\u093E\u0907\u090F\u0964",
        "\"{c}\" \u0938\u0947 \u0938\u0902\u092C\u0902\u0927\u093F\u0924 \u090F\u0915 \u091B\u094B\u091F\u093E \u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 (80 \u0936\u092C\u094D\u0926) \u0905\u092A\u0928\u0947 \u0936\u092C\u094D\u0926\u094B\u0902 \u092E\u0947\u0902 \u0932\u093F\u0916\u093F\u090F\u0964",
        "\"{c}\" \u0915\u0947 \u0915\u093F\u0938\u0940 \u092A\u093E\u0924\u094D\u0930, \u092D\u093E\u0935 \u092F\u093E \u0928\u093F\u092F\u092E \u0915\u093E \u0935\u093F\u0936\u094D\u0932\u0947\u0937\u0923 \u0915\u0940\u091C\u093F\u090F\u0964",
        "\"{c}\" \u0938\u0947 \u092E\u093F\u0932\u0928\u0947 \u0935\u093E\u0932\u0940 \u0938\u0940\u0916 \u0915\u094B \u0905\u092A\u0928\u0947 \u091C\u0940\u0935\u0928 \u0938\u0947 \u091C\u094B\u0921\u093C\u0915\u0930 \u0932\u093F\u0916\u093F\u090F\u0964",
        "\"{c}\" \u0938\u0947 \u091C\u0941\u0921\u093C\u0940 \u0905\u0936\u0941\u0926\u094D\u0927\u093F\u092F\u093E\u0901 \u0922\u0942\u0901\u0922\u093C\u0915\u0930 \u0936\u0941\u0926\u094D\u0927 \u0930\u0942\u092A \u0932\u093F\u0916\u093F\u090F\u0964",
        "\"{c}\" \u092A\u0930 \u090F\u0915 \u0932\u0918\u0941 \u0928\u093F\u092C\u0902\u0927 \u092F\u093E \u092A\u0924\u094D\u0930 \u0932\u093F\u0916\u093F\u090F\u0964",
        "\"{c}\" \u0915\u0947 \u0928\u093F\u092F\u092E \u0909\u0926\u093E\u0939\u0930\u0923 \u0938\u0939\u093F\u0924 \u0938\u092E\u091D\u093E\u0907\u090F\u0964",
        "\"{c}\" \u092A\u0930 \u0906\u0927\u093E\u0930\u093F\u0924 \u092A\u093E\u0901\u091A \u0905\u092D\u094D\u092F\u093E\u0938 \u092A\u094D\u0930\u0936\u094D\u0928 \u092C\u0928\u093E\u0915\u0930 \u0939\u0932 \u0915\u0940\u091C\u093F\u090F\u0964"
    )

    private val commerce = listOf(
        "Explain \"{c}\" with a suitable format or example (document, entry, ledger or chart) using your own figures.",
        "Solve a practical problem on \"{c}\" with full working and explain each step.",
        "Compare two terms, forms or methods in \"{c}\" in a table with reasons.",
        "Explain the advantages and limits of the main idea in \"{c}\" for a small business.",
        "Prepare a case study: a business faces a problem related to \"{c}\"; analyse it and advise.",
        "Write 5 hard short questions on \"{c}\" with answers.",
        "Explain the role of \"{c}\" in the working of a business or the economy.",
        "Draw a flow chart of the procedure in \"{c}\" and explain it.",
        "Identify common errors in \"{c}\" and show the correct treatment.",
        "Link \"{c}\" with another commerce chapter using an example.",
        "Explain the legal or ethical aspects connected with \"{c}\" with examples.",
        "What would happen to a business if \"{c}\" were ignored? Explain with examples."
    )

    private val pe = listOf(
        "Draw a neat labelled diagram (body system, field, court or equipment) for \"{c}\" and explain it.",
        "Explain the rules, skills or functions in \"{c}\" with examples.",
        "Design a 20-minute training or practice plan using \"{c}\".",
        "Explain how \"{c}\" improves health, fitness or performance, with reasons.",
        "Compare two techniques, systems or positions in \"{c}\" in a table.",
        "Explain common injuries or mistakes related to \"{c}\" and how to prevent them.",
        "Write the important terms of \"{c}\" with one-line explanations.",
        "Write 5 hard why/how questions on \"{c}\" and answer them.",
        "Explain how the rules of \"{c}\" ensure fair play and safety.",
        "Describe how a player could apply \"{c}\" in a real game situation.",
        "Explain how \"{c}\" is linked with another body system or sport.",
        "Write an exam-style long answer on \"{c}\"."
    )
}
