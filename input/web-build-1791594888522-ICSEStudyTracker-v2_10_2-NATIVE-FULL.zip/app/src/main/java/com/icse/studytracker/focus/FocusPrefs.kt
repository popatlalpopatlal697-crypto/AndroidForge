package com.icse.studytracker.focus

import android.content.Context

/** Focus Mode state shared by the UI, the foreground service and the accessibility service. */
class FocusPrefs(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("focus", Context.MODE_PRIVATE)

    fun endAt(): Long = p.getLong("endAt", 0L)

    fun isActive(): Boolean = endAt() > System.currentTimeMillis()

    fun start(endAt: Long) { p.edit().putLong("endAt", endAt).apply() }

    fun stop() { p.edit().putLong("endAt", 0L).apply() }

    fun packages(): Set<String> = p.getStringSet("packages", emptySet())?.toSet() ?: emptySet()

    fun setPackages(v: Set<String>) { p.edit().putStringSet("packages", HashSet(v)).apply() }

    fun labels(): String = p.getString("labels", "{}") ?: "{}"

    fun setLabels(json: String) { p.edit().putString("labels", json).apply() }
}
