package com.icse.studytracker.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.AppState
import com.icse.studytracker.data.objects
import org.json.JSONObject

/** Polls the backend for new community / DM messages and shows notifications. */
class ChatNotificationWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val state = AppState(applicationContext)
        if (!state.notificationsEnabled || state.cookie == null) return Result.success()
        Api.init(applicationContext)
        return try {
            val data = Api.trackerObj("notifications", JSONObject().put("since", state.lastNotificationAt))
            val items = data.optJSONArray("items")?.objects() ?: emptyList()
            var newest = state.lastNotificationAt
            for (item in items) {
                val id = item.optString("id").hashCode()
                val who = item.optString("displayName", "Student")
                val kind = if (item.optString("type") == "dm") "dm" else "community"
                val at = com.icse.studytracker.data.parseIso(item.optString("createdAt")).let { if (it > 0L) it else System.currentTimeMillis() }
                NotificationHelper.chatMessage(applicationContext, kind, who, item.optString("body"), at)
                val created = item.optString("createdAt")
                if (created > newest) newest = created
            }
            if (newest.isNotBlank()) state.lastNotificationAt = newest
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
