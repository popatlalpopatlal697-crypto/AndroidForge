package com.icse.studytracker.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.icse.studytracker.MainActivity

object NotificationHelper {
    const val CHAT_CHANNEL = "chat"
    const val STUDY_CHANNEL = "study_reminders"
    const val FOCUS_CHANNEL = "focus_timer"
    const val LIVE_CHANNEL = "live_updates"
    const val FRIENDS_CHANNEL = "friends_studying"
    private const val GROUP = "icse_study_tracker"

    fun channels(context: Context) {
        // Notification channels exist only on Android 8.0 (API 26)+.
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHAT_CHANNEL, "Community & DMs", NotificationManager.IMPORTANCE_HIGH).apply { description = "New community and private chat messages" })
        nm.createNotificationChannel(NotificationChannel(STUDY_CHANNEL, "Study reminders", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "Study and test reminders" })
        nm.createNotificationChannel(NotificationChannel(FOCUS_CHANNEL, "Focus timer", NotificationManager.IMPORTANCE_LOW).apply { description = "Ongoing focus session timer" })
        nm.createNotificationChannel(NotificationChannel(LIVE_CHANNEL, "Background updates", NotificationManager.IMPORTANCE_MIN).apply { description = "Keeps the app listening for new messages" })
        nm.createNotificationChannel(NotificationChannel(FRIENDS_CHANNEL, "Classmates studying", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "When a classmate studies" })
    }

    fun canNotify(context: Context): Boolean {
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun chat(context: Context, id: Int, title: String, body: String) {
        if (!canNotify(context)) return
        channels(context)
        val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra("openTab", "Chat") }
        val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0
        val pi = android.app.PendingIntent.getActivity(context, id, open, flags)
        val n = NotificationCompat.Builder(context, if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) CHAT_CHANNEL else "")
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title)
            .setContentText(body.ifBlank { "New message or attachment" })
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    }

    fun studyReminder(context: Context) {
        if (!canNotify(context)) return
        channels(context)
        val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra("openTab", "Timer") }
        val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0
        val pi = android.app.PendingIntent.getActivity(context, 901, open, flags)
        val n = NotificationCompat.Builder(context, if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) STUDY_CHANNEL else "")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("ICSE Study Tracker")
            .setContentText("A little focused study today keeps your streak moving.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(901, n)
    }

    fun friendStudy(context: Context, id: Int, title: String, body: String) {
        if (!canNotify(context)) return
        channels(context)
        val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra("openTab", "Board") }
        val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0
        val pi = android.app.PendingIntent.getActivity(context, id, open, flags)
        val n = NotificationCompat.Builder(context, if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) FRIENDS_CHANNEL else "")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    }

    private val history = HashMap<String, MutableList<Triple<String, String, Long>>>()

    private fun convKey(kind: String, sender: String): String = if (kind == "community") "community" else "dm:" + sender

    private fun convId(key: String): Int = 5000 + Math.abs(key.hashCode() % 1000)

    /** One notification per conversation that stacks the latest messages, like WhatsApp. Tapping opens that chat. */
    @Synchronized
    fun chatMessage(context: Context, kind: String, sender: String, text: String, timeMs: Long) {
        if (!canNotify(context)) return
        channels(context)
        val key = convKey(kind, sender)
        val list = history.getOrPut(key) { ArrayList() }
        // the same message can arrive from Firebase and from the built-in listener: show it only once
        val shown = text.ifBlank { "\uD83D\uDCCE Attachment" }
        fun generic(t: String) = t.startsWith("\uD83D\uDCCE") || t.startsWith("\uD83D\uDCF7") || t.startsWith("\uD83C\uDFA5") || t.startsWith("\uD83C\uDFA4") || t.startsWith("\uD83D\uDCCA")
        if (list.any { it.first == sender && Math.abs(it.third - timeMs) < 10_000L && (it.second == shown || generic(it.second) || generic(shown)) }) return
        list.add(Triple(sender, text.ifBlank { "\uD83D\uDCCE Attachment" }, timeMs))
        while (list.size > 7) list.removeAt(0)
        val me = androidx.core.app.Person.Builder().setName("You").build()
        val style = NotificationCompat.MessagingStyle(me)
        if (kind == "community") {
            style.setConversationTitle("Class IX Community")
            style.setGroupConversation(true)
        }
        for ((who, msg, t) in list) {
            style.addMessage(msg, t, androidx.core.app.Person.Builder().setName(who).build())
        }
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openTab", "Chat")
            putExtra("openChat", kind)
            putExtra("openName", sender)
        }
        val id = convId(key)
        val pf = android.app.PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0
        val pi = android.app.PendingIntent.getActivity(context, id, open, pf)
        val title = if (kind == "community") "Class IX Community" else sender
        val n = NotificationCompat.Builder(context, if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) CHAT_CHANNEL else "")
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title)
            .setContentText(if (kind == "community") sender + ": " + list.last().second else list.last().second)
            .setStyle(style)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setWhen(timeMs)
            .setShowWhen(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    }

    /** Removes the notification (and its stacked messages) once the chat has been opened. */
    @Synchronized
    fun clearChat(context: Context, kind: String, sender: String) {
        val key = convKey(kind, sender)
        history.remove(key)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(convId(key))
    }
}
