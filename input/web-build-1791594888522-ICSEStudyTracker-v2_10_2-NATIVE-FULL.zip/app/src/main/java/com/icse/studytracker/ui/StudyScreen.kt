package com.icse.studytracker.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.Syllabus

private val fieldLabels = listOf("read" to "Read", "notes" to "Notes", "practice" to "Practice", "revised" to "Revised")

@Composable
fun StudyScreen() {
    val subjects = Syllabus.subjectsFor(Repo.stream)
    val subject = if (subjects.contains(Repo.studySubject)) Repo.studySubject else subjects.first()
    val chapters = Syllabus.chaptersOf(subject)
    val doneCount = Repo.subjectFinished(subject)

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("CHAPTER TRACKER")
            H1("Tick what you have finished")
            MutedText("A chapter counts as finished when Read, Notes and Practice are ticked. Revised is your extra revision tick.")
            ProgressBar(Repo.overallPercent() / 100f, height = 12)
            MutedText("Overall: ${Repo.finishedChapters()}/${Repo.totalChapters()} chapters (${Repo.overallPercent()}%)")
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (s in subjects) Chip(s, s == subject, { Repo.studySubject = s }, Syllabus.colorOf(s))
        }

        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                H2(subject)
                MutedText("   $doneCount/${chapters.size} finished")
            }
            ProgressBar(if (chapters.isEmpty()) 0f else doneCount / chapters.size.toFloat(), tint = Syllabus.colorOf(subject))
            for (c in chapters) {
                val done = Repo.isFinished(Syllabus.key(subject, c))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(c, color = if (done) Good else Txt, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        for ((f, label) in fieldLabels) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                TickBox(Repo.has(subject, c, f), { Repo.toggleField(subject, c, f) })
                                Text(label, color = Muted, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
