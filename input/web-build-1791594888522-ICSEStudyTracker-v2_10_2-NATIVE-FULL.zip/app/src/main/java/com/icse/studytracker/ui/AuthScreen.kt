package com.icse.studytracker.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.foundation.clickable
import com.icse.studytracker.data.Repo

@Composable
fun AuthScreen() {
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(Repo.lastEmail()) }
    var pass by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf("Science") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(if (Repo.sessionExpired) "Your session expired. Please sign in again." else "") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.height(40.dp))
        Kicker("ICSE CLASS IX \u00B7 2026\u201327")
        Text("Study Tracker", color = Txt, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        MutedText("Track study time, finish the syllabus, beat your streak and climb the leaderboard.", size = 14)
        Spacer(Modifier.height(18.dp))
        NeonCard {
            H2(if (register) "Create your account" else "Welcome back")
            if (register) {
                Field(name, { name = it }, "Your name", Modifier.fillMaxWidth())
            }
            Field(email, { email = it }, "Email", Modifier.fillMaxWidth(), keyboard = KeyboardType.Email)
            Field(
                pass, { pass = it },
                if (register) "Password (8+ characters)" else "Password",
                Modifier.fillMaxWidth(), password = true
            )
            if (register) {
                MutedText("Your stream")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Science", chosen == "Science", { chosen = "Science" })
                    Chip("Commerce", chosen == "Commerce", { chosen = "Commerce" })
                }
            }
            if (error.isNotBlank()) Body(error, color = Bad, size = 13)
            NeonButton(
                if (busy) "Please wait\u2026" else if (register) "Create account" else "Sign in",
                onClick = {
                    error = ""
                    if (register && name.isBlank()) {
                        error = "Please enter your name."
                    } else if (!email.contains("@")) {
                        error = "Please enter a valid email."
                    } else if (pass.length < 8) {
                        error = "Password must be at least 8 characters."
                    } else {
                        busy = true
                        val done: (String?) -> Unit = { msg ->
                            busy = false
                            if (msg != null) error = msg
                        }
                        if (register) Repo.signUp(name, email, pass, chosen, done) else Repo.signIn(email, pass, done)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !busy
            )
            Text(
                if (register) "Already registered? Sign in" else "New here? Create an account",
                color = Cyan,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { register = !register; error = "" }
                    .padding(8.dp)
            )
        }
    }
}
