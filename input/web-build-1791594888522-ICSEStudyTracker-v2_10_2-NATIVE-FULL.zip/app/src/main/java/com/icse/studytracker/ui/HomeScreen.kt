package com.icse.studytracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.Syllabus
import com.icse.studytracker.data.fmtClock
import com.icse.studytracker.data.fmtDur

@Composable
fun HomeScreen() {
    val pct = Repo.overallPercent()
    val streak = Repo.streakDays()
    val todaySecs = Repo.secondsToday() + Repo.timerSeconds()
    val tasks = Repo.todaysTasks()
    val doneTasks = tasks.count { Repo.isFinished(it) }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("TODAY'S MISSION")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Hi ${Repo.userName.ifBlank { "Student" }}, keep going!",
                        color = Txt, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
                    )
                    MutedText("${Repo.finishedChapters()} of ${Repo.totalChapters()} chapters finished", size = 13)
                }
                Ring(pct)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("TODAY", fmtDur(todaySecs), Modifier.weight(1f))
                Stat("STREAK", "$streak day${if (streak == 1) "" else "s"}", Modifier.weight(1f))
                Stat("ALL TIME", fmtDur(Repo.secondsTotal()), Modifier.weight(1f))
            }
        }

        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Kicker("SYLLABUS PROGRESS")
                Text("  $pct%", color = Txt, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            ProgressBar(pct / 100f, height = 14)
            MutedText("Tick chapters in the Study tab to move this bar.")
        }

        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Kicker("DAILY TASKS")
                    if (tasks.isNotEmpty()) MutedText("$doneTasks of ${tasks.size} done today")
                }
                NeonButton("Planner", { Repo.tab = "Planner" }, secondary = true)
            }
            if (tasks.isEmpty()) {
                Body("No daily plan yet. Set your exam date and finish-by date in the Planner and I will split the syllabus into daily tasks.", color = Muted, size = 13)
            } else {
                ProgressBar(doneTasks / tasks.size.toFloat())
                for (k in tasks.take(6)) TaskRow(k)
                if (tasks.size > 6) MutedText("+${tasks.size - 6} more in the Planner")
            }
        }

        NeonCard {
            Kicker("STUDY TIMER")
            Text(
                fmtClock(Repo.timerSeconds()),
                color = Txt, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.fillMaxWidth()
            )
            MutedText("${Repo.timerSubject}${if (Repo.timerTopic.isBlank()) "" else " \u00B7 " + Repo.timerTopic}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton(if (Repo.timerRunning) "Pause" else "Start", { Repo.timerToggle() })
                NeonButton("Save", { if (!Repo.timerSave()) Repo.toast("Study at least 5 seconds first") }, secondary = true)
                NeonButton("Open timer", { Repo.tab = "Timer" }, secondary = true)
            }
        }

        NeonCard {
            Kicker("SUBJECTS")
            for (s in Syllabus.subjectsFor(Repo.stream)) {
                val total = Syllabus.chaptersOf(s).size
                val done = Repo.subjectFinished(s)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            Repo.studySubject = s
                            Repo.tab = "Study"
                        }
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row {
                        Text(s, color = Txt, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        MutedText("$done/$total")
                    }
                    ProgressBar(if (total == 0) 0f else done / total.toFloat(), tint = Syllabus.colorOf(s))
                }
            }
        }

        NeonCard {
            Kicker("TOP OF THE LEADERBOARD")
            if (Repo.board.isEmpty()) {
                MutedText("Study today to appear on the board!")
            } else {
                for ((i, r) in Repo.board.take(3).withIndex()) {
                    Row(Modifier.fillMaxWidth()) {
                        Text("${i + 1}. ${r.name}", color = Txt, modifier = Modifier.weight(1f))
                        MutedText(if (r.seconds <= 0L) "<1m" else fmtDur(r.seconds), size = 13)
                    }
                }
            }
            NeonButton("Full leaderboard", { Repo.tab = "Board" }, secondary = true)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Sunday tests", { Repo.tab = "Tests" }, Modifier.weight(1f))
            NeonButton("Focus mode", { Repo.tab = "Focus" }, Modifier.weight(1f), secondary = true)
        }
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        Text(value, color = Txt, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun TaskRow(key: String) {
    val subject = key.substringBefore("::")
    val chapter = key.substringAfter("::")
    val done = Repo.isFinished(key)
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        TickBox(done, { Repo.setFinished(key, !done) })
        Column(Modifier.weight(1f)) {
            Text(chapter, color = if (done) Muted else Txt, fontSize = 14.sp)
            Text(subject, color = Syllabus.colorOf(subject), fontSize = 11.sp)
        }
    }
}
