package com.icse.studytracker.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.draw.clip as androidxClip
import androidx.compose.foundation.background as androidxBackground
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.FAIL_PHRASE
import com.icse.studytracker.data.GradeResult
import com.icse.studytracker.data.Question
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.Syllabus
import com.icse.studytracker.data.fmtClock
import com.icse.studytracker.data.fmtDur
import com.icse.studytracker.data.timeOfDay

@Composable
fun TimerScreen() {
    val subjects = Syllabus.subjectsFor(Repo.stream)
    val subject = if (subjects.contains(Repo.timerSubject)) Repo.timerSubject else subjects.first()
    var showChapters by remember { mutableStateOf(false) }
    var topicVersion by remember { mutableStateOf(0) }
    var loadingQs by remember { mutableStateOf(false) }
    val uiScope = rememberCoroutineScope()

    var minutes by remember { mutableStateOf("30") }
    var step by remember { mutableStateOf(0) }
    var questions by remember { mutableStateOf<List<Question>>(emptyList()) }
    val choices = remember { mutableStateMapOf<Int, Int>() }
    val focus = LocalFocusManager.current
    var result by remember { mutableStateOf<GradeResult?>(null) }
    var message by remember { mutableStateOf("") }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("STUDY TIMER")
            Text(
                fmtClock(Repo.timerSeconds()),
                color = Txt, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            MutedText(
                if (Repo.timerRunning) "Running \u2014 you can leave the app, the timer keeps counting." else "Pick what you are studying, then press Start.",
                Modifier.fillMaxWidth()
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (s in subjects) Chip(s, s == subject, { Repo.timerSetSubject(s) }, Syllabus.colorOf(s))
            }
            key(topicVersion) {
                Field(Repo.timerTopic, { Repo.timerSetTopic(it) }, "Topic / chapter (optional)", Modifier.fillMaxWidth())
            }
            if (Repo.timerTopic.isNotBlank()) Body("Selected topic: ${Repo.timerTopic}", color = Cyan, size = 13)
            Chip(if (showChapters) "Hide chapters" else "Choose from ${subject} chapters", false, { showChapters = !showChapters })
            if (showChapters) {
                for (c in Syllabus.chaptersOf(subject)) {
                    Text(
                        c,
                        color = if (Repo.timerTopic == c) Cyan else Txt,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickableNoRipple { focus.clearFocus(); Repo.timerSetTopic(c); topicVersion++; showChapters = false }
                            .padding(vertical = 7.dp)
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton(if (Repo.timerRunning) "Pause" else if (Repo.timerSeconds() > 0) "Resume" else "Start", { Repo.timerToggle() }, Modifier.weight(1f))
                NeonButton("Save", {
                    if (!Repo.timerSave()) Repo.toast("Study for at least 5 seconds first")
                }, Modifier.weight(1f), secondary = true)
                NeonButton("Reset", { Repo.timerReset() }, Modifier.weight(1f), secondary = true)
            }
        }

        NeonCard {
            Kicker("ADD TIME MANUALLY \u00B7 AI QUESTIONS \u00B7 v2.9.2")
            MutedText("Forgot to start the timer? Add the minutes, then answer 5 multiple-choice questions the AI writes about exactly your topic (3 correct) to prove you studied.")
            if (step == 0 || step == 4) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Field(minutes, { minutes = it.filter { ch -> ch.isDigit() }.take(3) }, "Minutes", Modifier.weight(1f), keyboard = KeyboardType.Number)
                    NeonButton(
                        if (loadingQs) "Making questions\u2026" else "Verify & add",
                        onClick = {
                            val m = minutes.toIntOrNull() ?: 0
                            if (m < 1 || m > 600) {
                                message = "Enter between 1 and 600 minutes."
                            } else if (Repo.timerTopic.isBlank()) {
                                message = "Choose or type the topic you studied in the topic box above first."
                            } else if (!loadingQs) {
                                message = ""
                                loadingQs = true
                                val topic = Repo.timerTopic.trim()
                                uiScope.launch {
                                    try {
                                        val qs = Repo.aiVerificationQuestions(subject, topic)
                                        result = null
                                        questions = qs
                                        choices.clear()
                                        step = 2
                                    } catch (e: Exception) {
                                        message = Repo.handleError(e)
                                    }
                                    loadingQs = false
                                }
                            }
                        }
                    )
                }
            }
            if (message.isNotBlank()) Body(message, color = Bad, size = 13)
            if (step == 2) {
                Body("Topic: ${Repo.timerTopic}  \u00B7  $subject", color = Muted, size = 12)
                for ((i, q) in questions.withIndex()) {
                    Body("${i + 1}. ${q.q}", size = 15)
                    for ((oi, opt) in q.options.withIndex()) {
                        val picked = choices[i] == oi
                        val shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .androidxClip(shape)
                                .androidxBackground(if (picked) Violet.copy(alpha = 0.25f) else Panel)
                                .clickableNoRipple { choices[i] = oi }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("${'A' + oi}", color = if (picked) Cyan else Muted, fontWeight = FontWeight.Bold)
                            Text(opt, color = Txt, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }
                NeonButton(
                    "Submit answers",
                    onClick = {
                        if (choices.size < questions.size) {
                            message = "Answer all 5 questions first."
                        } else {
                            message = ""
                            var correct = 0
                            for ((i, q) in questions.withIndex()) if (choices[i] == q.answer) correct++
                            val passed = correct >= 3
                            result = GradeResult(correct, passed, emptyList())
                            if (passed) {
                                val m = minutes.toIntOrNull() ?: 0
                                Repo.recordSession(subject, Repo.timerTopic.trim(), m * 60, true)
                                Repo.toast("Verified! Added $m minutes")
                            }
                            step = 4
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            val r = result
            if (step == 4 && r != null) {
                if (r.passed) {
                    Body("\u2705 Verified (${r.correct}/5 correct). ${minutes} minutes were added to your study time.", color = Good, size = 14)
                } else {
                    Body("${r.correct}/5 correct. $FAIL_PHRASE", color = Bad, size = 15)
                    MutedText("You need 3 correct. Study the topic properly and try again \u2014 no time was added.")
                }
            }
        }

        NeonCard {
            Kicker("RECENT SESSIONS")
            if (Repo.rows.isEmpty()) {
                MutedText("No sessions yet \u2014 start the timer above.")
            } else {
                for (row in Repo.rows.take(10)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(row.subject, color = Syllabus.colorOf(row.subject), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            val sub = (if (row.chapter.isBlank()) "" else row.chapter + " \u00B7 ") + timeOfDay(row.at)
                            MutedText(sub + if (row.verified) " \u00B7 verified" else "" + if (row.pending) " \u00B7 syncing" else "")
                        }
                        Text(fmtDur(row.seconds.toLong()), color = Txt, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
