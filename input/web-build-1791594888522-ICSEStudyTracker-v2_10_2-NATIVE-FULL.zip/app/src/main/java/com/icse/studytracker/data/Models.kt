package com.icse.studytracker.data

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class StudyRow(
    val subject: String,
    val chapter: String,
    val seconds: Int,
    val at: Long,
    val verified: Boolean,
    val pending: Boolean = false
)

data class LeaderRow(val name: String, val seconds: Long, val streak: Int)

data class Member(val id: String, val name: String, val streak: Int, val minutes: Int, val lastSeen: Long = 0L)

data class Question(
    val q: String,
    val options: List<String>,
    val answer: Int,
    val explanation: String,
    val marks: Int,
    val difficulty: String,
    val subject: String,
    val chapter: String,
    val written: Boolean = false,
    val photoRequired: Boolean = false,
    val guide: String = ""
)

data class TestDef(
    val slot: Int,
    val questions: List<Question>,
    val subject: String = "",
    val chapter: String = ""
) {
    val mcqCount: Int get() = questions.count { !it.written }
    val writtenCount: Int get() = questions.count { it.written }
    val totalMarks: Int get() = questions.sumOf { it.marks }
}

data class Attempt(val test: Int, val score: Double, val total: Double, val at: Long)

data class GradeResult(val correct: Int, val passed: Boolean, val feedback: List<String>)

data class AppInfo(val label: String, val pkg: String)

const val FAIL_PHRASE = "ehha immandari chalata babu \uD83D\uDE02\uD83D\uDE02lol"

fun JSONArray.objects(): List<JSONObject> {
    val out = ArrayList<JSONObject>()
    for (i in 0 until length()) {
        val o = optJSONObject(i)
        if (o != null) out.add(o)
    }
    return out
}

fun JSONArray.strings(): List<String> {
    val out = ArrayList<String>()
    for (i in 0 until length()) out.add(optString(i, ""))
    return out
}

fun parseIso(s: String?): Long {
    if (s.isNullOrBlank() || s.length < 19) return 0L
    return try {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        f.parse(s.take(19))?.time ?: 0L
    } catch (e: Exception) {
        0L
    }
}

fun dayKey(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

fun todayKey(): String = dayKey(System.currentTimeMillis())

fun addDays(key: String, days: Int): String {
    val cal = Calendar.getInstance()
    try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key)
        if (d != null) cal.time = d
    } catch (e: Exception) {
        // keep today
    }
    cal.add(Calendar.DAY_OF_YEAR, days)
    return dayKey(cal.timeInMillis)
}

fun addMonths(key: String, months: Int): String {
    val cal = Calendar.getInstance()
    try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key)
        if (d != null) cal.time = d
    } catch (e: Exception) {
        // keep today
    }
    cal.add(Calendar.MONTH, months)
    return dayKey(cal.timeInMillis)
}

fun daysBetween(from: String, to: String): Int {
    return try {
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val a = f.parse(from)?.time ?: 0L
        val b = f.parse(to)?.time ?: 0L
        Math.round((b - a) / 86400000.0).toInt()
    } catch (e: Exception) {
        0
    }
}

fun prettyDate(key: String): String {
    return try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key)
        if (d == null) key else SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(d)
    } catch (e: Exception) {
        key
    }
}

fun fmtClock(sec: Long): String {
    val s = if (sec < 0) 0 else sec
    val h = s / 3600
    val m = (s % 3600) / 60
    val r = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, r) else String.format(Locale.US, "%02d:%02d", m, r)
}

fun fmtDur(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    return when {
        h > 0 -> "${h}h ${m}m"
        m > 0 -> "${m}m"
        else -> "${sec}s"
    }
}

fun timeOfDay(ms: Long): String =
    if (ms <= 0L) "" else SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ms))

fun stampOf(ms: Long): String =
    if (ms <= 0L) "" else SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(ms))

fun lastSeenText(ts: Long): String {
    if (ts <= 0L) return ""
    val diff = System.currentTimeMillis() - ts
    if (diff < 90_000L) return "online"
    val day = dayKey(ts)
    return when (day) {
        todayKey() -> "last seen today at " + timeOfDay(ts)
        addDays(todayKey(), -1) -> "last seen yesterday at " + timeOfDay(ts)
        else -> "last seen " + prettyDate(day) + " at " + timeOfDay(ts)
    }
}
