# Firebase push notifications (v2.10.0)

Server side is already done in the Floot project (secret FCM_SERVICE_ACCOUNT_JSON, project fir-app-786af,
action `push_register`, token table, push on every community post and DM).

Only ONE file is needed to finish the Android side:

1. Firebase console -> project fir-app-786af -> Project settings -> General -> Your apps.
2. Add an Android app with package name `com.icse.class9studytracker` (skip if it already exists).
3. Download `google-services.json` and put it here: `app/google-services.json`
   (same folder as `app/build.gradle.kts`).
4. Build the APK again. Without the file the app still builds and works; it just uses the old built-in listener.

How it works: after login the app sends its Firebase token to the server; when anyone posts in the community
or sends a DM, the server pushes it to the other phones and the app shows the WhatsApp-style notification,
even when the app is closed.
